import * as duckdb from 'duckdb';
import * as path from 'path';
import * as fs from 'fs';

// ─────────────────────────────────────────────
// DuckDB singleton
// Single persistent connection per process
// ─────────────────────────────────────────────

const DB_PATH = path.resolve(process.env.DB_PATH ?? './data/forensics.duckdb');

let _db: duckdb.Database | null = null;
let _conn: duckdb.Connection | null = null;

export function getDb(): duckdb.Database {
  if (!_db) {
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    _db = new duckdb.Database(DB_PATH);
  }
  return _db;
}

export function getConnection(): duckdb.Connection {
  if (!_conn) {
    _conn = new duckdb.Connection(getDb());
  }
  return _conn;
}

/**
 * Run a query and return all rows as plain objects.
 * Wraps the callback-based DuckDB API in a Promise.
 */
export function query<T = Record<string, unknown>>(
  sql: string,
  params: unknown[] = []
): Promise<T[]> {
  return new Promise((resolve, reject) => {
    const conn = getConnection();
    conn.all(sql, ...params, (err: Error | null, rows: T[]) => {
      if (err) reject(err);
      else resolve(rows ?? []);
    });
  });
}

/**
 * Run a statement that returns no rows (CREATE, INSERT, etc.)
 */
export function execute(sql: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const conn = getConnection();
    conn.exec(sql, (err: Error | null) => {
      if (err) reject(err);
      else resolve();
    });
  });
}

export async function closeDb(): Promise<void> {
  return new Promise((resolve) => {
    if (_db) {
      _db.close(() => {
        _db = null;
        _conn = null;
        resolve();
      });
    } else {
      resolve();
    }
  });
}

import { FastifyInstance } from 'fastify';
import { ingestFiles, getIngestStatus } from '../ingestion/converter';
import { validateFilePaths } from '../ingestion/watcher';
import { ApiResponse, IngestRequest, IngestStatus } from '../shared/types';

export async function ingestRoutes(app: FastifyInstance): Promise<void> {
  /**
   * POST /ingest
   * Body: { file_paths: string[] }
   * Starts ingestion pipeline. Non-blocking — returns immediately.
   * Poll GET /ingest/status for progress.
   */
  app.post<{ Body: IngestRequest }>('/ingest', async (req, reply) => {
    const { file_paths } = req.body ?? {};

    if (!Array.isArray(file_paths) || file_paths.length === 0) {
      return reply.code(400).send({
        ok: false,
        error: 'Body must include file_paths: string[]',
      } satisfies ApiResponse<never>);
    }

    const current = getIngestStatus();
    if (current.running) {
      return reply.code(409).send({
        ok: false,
        error: 'Ingestion already in progress',
      } satisfies ApiResponse<never>);
    }

    const { valid, invalid } = validateFilePaths(file_paths);

    if (valid.length === 0) {
      return reply.code(400).send({
        ok: false,
        error: `No valid .log files found. Issues: ${invalid.map(i => `${i.path}: ${i.reason}`).join(', ')}`,
      } satisfies ApiResponse<never>);
    }

    // Fire ingestion — non-blocking
    ingestFiles(valid).catch(err => {
      console.error('[route /ingest] Unhandled error:', err);
    });

    return reply.code(202).send({
      ok: true,
      data: {
        accepted: valid.length,
        skipped: invalid,
        message: 'Ingestion started. Poll GET /ingest/status for progress.',
      },
    } satisfies ApiResponse<unknown>);
  });

  /**
   * GET /ingest/status
   * Returns current ingestion progress.
   */
  app.get('/ingest/status', async (_req, reply) => {
    return reply.send({
      ok: true,
      data: getIngestStatus(),
    } satisfies ApiResponse<IngestStatus>);
  });
}

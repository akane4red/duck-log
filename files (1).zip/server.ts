import Fastify from 'fastify';
import cors from '@fastify/cors';
import { filesRoutes } from './routes/files';
import { ingestRoutes } from './routes/ingest';
import { queryRoutes } from './routes/query';
import { registerUnifiedView } from './ingestion/converter';
import { closeDb } from './db/connection';

// ─────────────────────────────────────────────
// Server bootstrap
// ─────────────────────────────────────────────

const PORT = Number(process.env.PORT ?? 3001);
const HOST = process.env.HOST ?? '127.0.0.1';

const app = Fastify({
  logger: {
    transport: {
      target: 'pino-pretty',
      options: { colorize: true, translateTime: 'SYS:HH:MM:ss', ignore: 'pid,hostname' },
    },
  },
});

async function bootstrap(): Promise<void> {
  // CORS — allow React dev server and same-origin
  await app.register(cors, {
    origin: [
      'http://localhost:3000',
      'http://localhost:5173',  // Vite default
      'http://127.0.0.1:3000',
      'http://127.0.0.1:5173',
    ],
    methods: ['GET', 'POST', 'OPTIONS'],
  });

  // Routes
  await app.register(filesRoutes);
  await app.register(ingestRoutes);
  await app.register(queryRoutes);

  // Health check
  app.get('/health', async () => ({
    ok: true,
    version: '1.0.0',
    timestamp: new Date().toISOString(),
  }));

  // On startup, register any parquet files that already exist from a previous session
  // so queries work immediately without re-ingesting
  try {
    await registerUnifiedView();
  } catch {
    // No parquet files yet — that's fine, ingestion hasn't run
    app.log.info('No existing parquet files found — waiting for first ingestion');
  }

  // Graceful shutdown
  const shutdown = async (signal: string) => {
    app.log.info(`Received ${signal} — shutting down`);
    await app.close();
    await closeDb();
    process.exit(0);
  };

  process.on('SIGINT',  () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));

  // Start
  await app.listen({ port: PORT, host: HOST });
  app.log.info(`IIS Forensics backend running at http://${HOST}:${PORT}`);
}

bootstrap().catch(err => {
  console.error('Fatal startup error:', err);
  process.exit(1);
});
